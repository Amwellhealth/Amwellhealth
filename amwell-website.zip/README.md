# AMWELL Research Lab — static website

This is a static export of the AMWELL Research Lab website, ready for GitHub Pages.

## Publish on GitHub Pages

1. Create a new repository on GitHub (e.g. `amwell-site`).
2. Upload ALL files and folders from this zip to the repository
   (keep the folder structure: `index.html` must be at the top level).
3. In the repo: Settings → Pages → Source: "Deploy from a branch" → Branch: `main`, folder: `/ (root)` → Save.
4. Your site will be live at `https://<your-username>.github.io/<repo-name>/` within a few minutes.

## Contents

- `index.html` and page folders (`about/`, `research/`, `team/`, ...) — all pages
- `images/` — logo files and team headshots
- `assets/styles.css` — the site's styling
- `favicon.png` — browser tab icon

## Notes

- The Contact and Get Involved forms display a thank-you message but do not
  send email (GitHub Pages cannot run a server). To receive messages, connect
  a form service such as Formspree later.
- To edit text, edit the HTML files directly, or ask for an updated export.
